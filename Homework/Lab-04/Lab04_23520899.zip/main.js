function init() {
    const scene = new THREE.Scene();

    var mesh = getBox(1, 1, 1);
    var plane = getPlane(4);

    mesh.position.y = mesh.geometry.parameters.height / 2;
    plane.rotation.x = Math.PI / 2;

    scene.add(plane);
    scene.add(mesh);

    var camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);

    camera.position.x = 1;
    camera.position.y = 2;
    camera.position.z = 5;

    camera.lookAt(new THREE.Vector3(0, 0, 0));

    var renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.getElementById("webgl").appendChild(renderer.domElement);
    renderer.render(scene, camera);


}

function getBox(w, h, d) {
    var geometry = new THREE.BoxGeometry(w, h, d);
    var material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
    var mesh = new THREE.Mesh(geometry, material);
    return mesh;
}

function getPlane(size) {
    var geometry = new THREE.PlaneGeometry(size, size);
    var material = new THREE.MeshBasicMaterial({ color: 0xff0000, side: THREE.DoubleSide });
    var mesh = new THREE.Mesh(geometry, material);
    return mesh;
}

init();